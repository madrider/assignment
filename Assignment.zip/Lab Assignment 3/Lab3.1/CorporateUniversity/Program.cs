﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Details;

namespace CorporateUniversity
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Participant p = new Participant();
                Console.WriteLine("Enter Foundation Marks");
                p.FoundationMarks = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Enter WebBasic Marks");
                p.WebBasicMarks = Int32.Parse(Console.ReadLine());
                Console.WriteLine("Enter DotNet Marks");
                p.DotNetMarks = Int32.Parse(Console.ReadLine());
                int ObMarks = p.ObtainedMarks1(p.FoundationMarks, p.WebBasicMarks, p.DotNetMarks);
                Console.WriteLine("Total Marks Obtained:{0}",ObMarks);
                float Percent = p.CalPercent(ObMarks);
                Console.WriteLine("Your Percentage is:{0}",Percent);
                Console.Read();
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.ReadKey();
            }
        }
    }
}
