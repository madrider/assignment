﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Lab6._2
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                Product p = new Product();
                Console.WriteLine("Enter Product Id");
                p.ProductId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Product Name");
                p.ProductName = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Enter Product Price");
                p.ProductPrice = Convert.ToInt32(Console.ReadLine());
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            


        }


    }
}
