﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6._2
{
    class Product
    {
        int ProId;
        string ProName;
        int Price;

        public int ProductId
        {
            get { return ProId; }
            set
            {
                if (value > 0)
                {
                    ProId = value;
                    
                }
                else
                {
                    throw new DataEntryException("Product Id should be greater than zero");
                }
            }
        }
        public string ProductName
        {
            get { return ProName; }
            set
            {
                if (value != "")
                {
                    ProName = value;

                }
                else
                {
                    throw new DataEntryException("Product Name cannot be blank");
                }
            }
        }
        public int ProductPrice
        {
            get { return Price; }
            set
            {
                if (value > 0)
                {
                    Price = value;
                    
                }
                else{
                    throw new DataEntryException("Price of product must be greater than zero.");
                }
            }
        }
    }
}
