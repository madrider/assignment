﻿using System;
namespace Lab6._1
{
    public class TestTemperature
    {
        static void Main(string[] args)
        {
            Customer cust1 = new Customer();
            Console.WriteLine("Customer Id:");
            cust1.CustId = int.Parse(Console.ReadLine());
            Console.WriteLine("Customer Name:");
            cust1.CustName = Console.ReadLine();
            Console.WriteLine("Customer Address:");
            cust1.Address = Console.ReadLine();
            Console.WriteLine("Customer city:");
            cust1.City = Console.ReadLine();
            Console.WriteLine("Customer phone number:");
            cust1.PhoneNo = Console.ReadLine();



            try
            {
                Console.WriteLine("Customer Limit");
                cust1.Limit = int.Parse(Console.ReadLine());
            }
            catch (InvalidCreditLimitException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();

            Console.WriteLine("Data Submitted");
        }
    }
}

