﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bank;

namespace Lab5._1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            ICICI i1 = new ICICI();
            i1.AccountType = Banks.BankAccountTypeEnum.Current;
            i1.Deposit(6000);

            HSBC h1 = new HSBC();
            h1.AccountType = Banks.BankAccountTypeEnum.Saving;
            h1.Deposit(5000);

            ICICI i2 = new ICICI();
            i2.AccountType = Banks.BankAccountTypeEnum.Current;
            i2.Deposit(20000);

            i1.Transfer(i2, 5000);

            HSBC i3 = new HSBC();
            i3.AccountType = Banks.BankAccountTypeEnum.Saving;
            i3.Deposit(50000);

            Console.WriteLine();
            HSBC i4 = new HSBC();
            i4.AccountType = Banks.BankAccountTypeEnum.Current;
            i4.Deposit(50000);

            i3.Transfer(i4, 3000);

            Console.Read();
        }
    }
}
