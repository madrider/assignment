﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Books
{
    public class BookDetails
    {
        public void colName()
        {
            string[] arr = new string[4] { "BookTitle", "Author", "Publisher", "Price" };
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i]+" ");
            }
        }
        public void BookDetail()
        {
            string[,] arr1 = new string[2, 4];
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    arr1[i,j] = Console.ReadLine();
                }
            }
            colName();
            Console.WriteLine();
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write(arr1[i,j]+"\t");
                }
                Console.WriteLine();
            }
        }

    }
}
