﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            MyStruct s = new MyStruct();
           
            Console.WriteLine("Enter Choice 1 or 2:");
            int c = int.Parse(Console.ReadLine());
            switch (c)
            {
                case 1:
                    Console.WriteLine("Enter Number:");
                    s.Square = int.Parse(Console.ReadLine());
                    s.displaySquare();
                    break;
                case 2:
                    Console.WriteLine("Enter Number:");
                    s.Cube = int.Parse(Console.ReadLine());
                    s.displayCube();
                    break;
            }
        }
    }
}
