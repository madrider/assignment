﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
        public struct MyStruct
        {
            public int number;
       
        public int Square
            {
                get { return number*number ; }
                set { number = value; }
            }
            public int Cube
            {
                get { return number * number * number; }
                set { number = value; }
            }
            public void displaySquare()
            {
                Console.WriteLine("The Square of the no is :" + Square);
            }
            public void displayCube()
            {
                Console.WriteLine("The Cube of the no is :" + Cube);
            }


        }

    }

