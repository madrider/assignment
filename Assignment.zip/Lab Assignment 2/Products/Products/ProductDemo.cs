﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Products
{
    class ProductDemo
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the id of Product : ");
            int ProductID = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name of Product : ");
            string ProductName = Console.ReadLine();
            Console.WriteLine("Enter price : ");
            double Price = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter Quantity : ");
            int Quantity = int.Parse(Console.ReadLine());
            
            //Boxing ProductID
            object objProductID = ProductID;
            //Unboxing ProductID
            int ProductUB_ID = (int)objProductID;

            //Boxing ProductName
            object objProductName = ProductName;
            //Unboxing ProductName
            string ProductUB_Name = (string)objProductName;

            //Boxing Price
            object objPrice = Price;
            //Unboxing Price
            double ProductUB_Price = (double)objPrice;

            //Boxing Quantity
            object objQuantity = Quantity;
            //Unboxing Quantity
            int ProductUB_Quantity = (int)objQuantity;

            Console.WriteLine();
            Console.WriteLine("Product Details : ");
            Console.WriteLine("Product Id : {0}",ProductUB_ID);
            Console.WriteLine("Product Name : {0}", ProductUB_Name);
            Console.WriteLine("Price : {0}", ProductUB_Price);
            Console.WriteLine("Quantity : {0}", ProductUB_Quantity);
            Console.WriteLine("Amount Payable {0}", ProductUB_Price* ProductUB_Quantity);

        }
    }
    }
    

