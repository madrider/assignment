﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_assignment_7._1
{
    class ContactClass
    {
        public int ContactNo
        {
            get
            {
                return ContactNo;
            }
            set
            {
                ContactNo = value;
            }
        }
        public string ContactName
        {
            get
            {
                return ContactName;
            }
            set
            {
                ContactName = value;
            }
        }
        public string CellNo
        {
            get
            {
                return CellNo;
            }
            set
            {
                CellNo = value;
            }
        }
    }
}
