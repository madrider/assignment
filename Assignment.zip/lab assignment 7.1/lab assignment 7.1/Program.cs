﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_assignment_7._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the choice ");
            int choice = int.Parse(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    AddContact();
                    break;
                case 2:
                    DisplayContact();
                    break;
                case 3:
                    EditContact();
                    break;
                case 4:
                    ShowAllContacts();
                    break;
                default:
                    Console.WriteLine("error");
                    break;
            }
        }
        public static  void AddContact()
        {

        }

        public static  void DisplayContact()
        {

        }

        public  static void EditContact()
        {

        }
        public static void ShowAllContacts()
        {
            foreach (var item in collection)
            {

            }
        }
    }
   }


