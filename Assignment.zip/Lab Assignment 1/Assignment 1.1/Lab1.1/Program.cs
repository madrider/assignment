﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Details;

namespace Lab1._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee();
            
            Employee[] emp = new Employee[2];
            for (int i = 0; i < 3; i++)
            {
                emp[i] = new Employee();
                Console.WriteLine("Enter the EmpId");
                emp1.EmpId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the EmpName");
                emp1.EmpName = Console.ReadLine();
                Console.WriteLine("Enter the address");
                emp1.Address1 = Console.ReadLine();
                Console.WriteLine("Enter the city");
                emp1.City1 = Console.ReadLine();
                Console.WriteLine("Enter the dept");
                emp1.Dept = Console.ReadLine();
                Console.WriteLine("Enter the salary");
                emp1.Sal = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                Console.WriteLine("Welcome \n Your details are as follows:\n Employee ID:{0}\n Employee Name:{1}\n Address:{2} \n City:{3} \n Department:{4}\n Salary:{5}", emp1.EmpId, emp1.EmpName, emp1.Address1, emp1.City1, emp1.Dept, emp1.Sal);
                Console.ReadLine();
            }
        }
    }
}