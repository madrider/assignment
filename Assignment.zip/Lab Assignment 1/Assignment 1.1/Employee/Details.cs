﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Details
{
    public class Employee
    {
        int empId;

        public int EmpId
        {
            get { return empId; }
            set { empId = value; }
        }
        string empName;

        public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }
        string Address;

        public string Address1
        {
            get { return Address; }
            set { Address = value; }
        }
        string City;

        public string City1
        {
            get { return City; }
            set { City = value; }
        }
        string dept;

        public string Dept
        {
            get { return dept; }
            set { dept = value; }
        }
        int sal;

        public int Sal
        {
            get { return sal; }
            set { sal = value; }
        }
    }
}
