﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1._4
{
    class Program
    {
        static Students emp = null;
        static Students[] emps = new Students[2];
        static void Main(string[] args)
        {
            PrintMenu();
        }

        static void PrintMenu()


        {
            int choice = 0;
            do
            {


                Console.WriteLine("Please Select your option:\n1. Set STUDENT Data\n2. Display  Data\n3.Add Students \n4.PrintAll\n5. Exit\n6. Enter your choice");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        SetData();
                        Console.WriteLine(" data saved");
                        break;
                    case 2:
                        emp.PrintDetails();
                        Console.WriteLine();
                        break;
                    case 3:
                        AddEmployees();



                        break;
                    case 4:
                        PrintAllRecords();
                        break;
                    case 5:

                        break;
                    default:
                        Console.WriteLine("Invalid Option selected");
                        break;
                }

            } while (choice != 4);




        }

        static void SetData()
        {
            emp = new Students();
            Console.WriteLine("Enter Roll no.");
            emp.RollNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter name");
            emp.StudentName = Console.ReadLine();
            Console.WriteLine("enter age");
            emp.Age = byte.Parse(Console.ReadLine());
            Console.WriteLine("enter gender");
            emp.Gender = char.Parse(Console.ReadLine());
            Console.WriteLine("enter dob");
            emp.DateOfBirth = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("enter Address");
            emp.Address = Console.ReadLine();
            Console.WriteLine("enter percentage");
            emp.Percentage = float.Parse(Console.ReadLine());
            
        }
        static void PrintData()
        {
            emp.PrintDetails();
        }
        static void AddEmployees()
        {
            for (int i = 0; i < 2; i++)
            {
                SetData();
                emps[i] = emp;

            }
        }
        static void PrintAllRecords()
        {
            foreach (Students item in emps)
            {
                item.PrintDetails();
                Console.WriteLine();
            }
        }
    }
}
