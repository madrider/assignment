﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1._4
{
    class Students
    {
        public int RollNumber;
        public string StudentName;
        public byte Age;
        public char Gender;
        public DateTime DateOfBirth;
        public string Address;
        public float Percentage;

        public void PrintDetails()
        {
            Console.WriteLine("RollNumber:{0} Name:{1} Age:{2} Gender:{3} DOB:{4} Address:{5} Percentage:{6}", RollNumber, StudentName, Age,Gender, DateOfBirth.ToShortDateString(),Address,Percentage);

        }
        public void SetData(int rollNumber, string studentName, byte age, char gender, DateTime dateOfBirth, string address, float percentage)
        {
            RollNumber = rollNumber;
            StudentName = studentName;
            Age = age;
            Gender = gender;
            DateOfBirth = dateOfBirth;
            Address = address;
            Percentage = percentage;
        }
    }
}
