﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathLib
{
    public class MathClass
    {
        public int Add(int number1, int number2)
        {
            return (number1 + number2);
        }
        public int Sub(int number1, int number2)
        {
            return (number1 - number2);
        }
        public int Mul(int number1, int number2)
        {
            return (number1 * number2);
        }
        public int Div(int number1, int number2)
        {
            return (number1 / number2);
        }
        public int Mod(int number1, int number2)
        {
            return (number1 % number2);
        }
        public double Add(double number1, double number2)
        {
            return (number1 + number2);
        }
        public double Sub(double number1, double number2)
        {
            return (number1 - number2);
        }
        public double Mul(double number1, double number2)
        {
            return (number1 * number2);
        }
        public double Div(double number1, double number2)
        {
            return (number1 / number2);
        }
        public double Mod(double number1, double number2)
        {
            return (number1 % number2);
        }
    }
}
