﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLib;

namespace CalculatorUI
{
    class Program
    {
        static void Main(string[] args)
        {
           
            MathClass mcobj = new MathClass();
                Console.WriteLine("1.Int\n2.Double");
                Console.WriteLine("Enter your choice");
                int ch2 = int.Parse(Console.ReadLine());
                switch (ch2)
                {
                    case 1:
                        Console.WriteLine("Enter First Number");
                        int num1 = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Second Number");
                        int num2 = int.Parse(Console.ReadLine());

                        Console.WriteLine("1.Add\n2.Sub\n3.Mul\n4.Div\n5.Mod");
                        Console.WriteLine("Enter your choice");
                        int ch = int.Parse(Console.ReadLine());
                        switch (ch)
                        {
                            case 1:
                                int result = mcobj.Add(num1, num2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            case 2:
                                result = mcobj.Sub(num1, num2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            case 3:
                                result = mcobj.Mul(num1, num2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            case 4:
                                result = mcobj.Div(num1, num2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            case 5:
                                result = mcobj.Mod(num1, num2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            default:
                                Console.WriteLine("Wrong Choice Entered");
                                break;
                        }
                        break;
                    case 2:
                        Console.WriteLine("Enter First Number");
                        double dnum1 = double.Parse(Console.ReadLine());
                        Console.WriteLine("Enter Second Number");
                        double dnum2 = double.Parse(Console.ReadLine());
                        Console.WriteLine("1.Add\n2.Sub\n3.Mul\n4.Div\n5.Mod");
                        Console.WriteLine("Enter your choice");
                        int ch1 = int.Parse(Console.ReadLine());
                        switch (ch1)
                        {
                            case 1:
                                Double result = mcobj.Add(dnum1, dnum2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            case 2:
                                result = mcobj.Sub(dnum1, dnum2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            case 3:
                                result = mcobj.Mul(dnum1, dnum2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            case 4:
                                result = mcobj.Div(dnum1, dnum2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            case 5:
                                result = mcobj.Div(dnum1, dnum2);
                                Console.WriteLine("Result is:" + result);
                                break;
                            default:
                                Console.WriteLine("Wrong Choice Entered");
                                break;
                        }
                        break;
                    case 3: break;
                }
           
        }
    }
}
