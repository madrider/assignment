﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1._3
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice = 0;
            Console.WriteLine("Enter the integer choice");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    choice = 1;
                    Console.WriteLine("Input is 1");
                    break;
                case 2:
                    choice = 2;
                    Console.WriteLine("Input is 2");
                    break;
                case 3:
                    choice = 3;
                    Console.WriteLine("Input is 3");
                    break;
                case 4:
                    choice = 4;
                    Console.WriteLine("Input is 4");
                    break;
                case 5:
                    choice = 5;
                    Console.WriteLine("Input is 5");
                    break;




                default:
                    Console.WriteLine("Invalid Input");
                    break;
            }
        }
    }
}
